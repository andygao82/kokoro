<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'kokoro' );

/** MySQL database username */
define( 'DB_USER', 'root' );

/** MySQL database password */
define( 'DB_PASSWORD', '' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database Charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The Database Collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'V`d_SsM,6ZYi8I~G]YE4YC[Sj$eZo$S|xRFA4? M!Wg[GsX[7A~%!!~I?)e;+>r6' );
define( 'SECURE_AUTH_KEY',  'o%n(a,+$JQ5)p5k {&-BJt{rkP3ui=}iGKAXsz66,wHkz{TFMLqA{QwQ`v|J+H;V' );
define( 'LOGGED_IN_KEY',    'QEv(3U=&{7Eckjia31^wv)~x;^HSVju9ut&f}zX~wFaiERe+~R%@ds,D[=u9MhJe' );
define( 'NONCE_KEY',        'TW#5z<w:_@m<SXB:clW;)f3REmo>.>)C0$lh.2Qj5>vQus#<uQ]jjcC^9%I@IOmz' );
define( 'AUTH_SALT',        '5dHW1`Q2PbB&zft1.4R%vE#H5fAU1oIZgXh/?C;9@n-Bg/3fT p_E-F<T4r;TF=%' );
define( 'SECURE_AUTH_SALT', 'aY*Hcfc^&Ck[j`9H1Y;>~+l:|^L31k%q2p5sg:Z[L$DT/d2U}HZG&XVTxc.y!0.V' );
define( 'LOGGED_IN_SALT',   '`4)WB^Se~M0N}.DIVwMnOs,hcLzZ|0jdjK|:j=hg(i*obWM+,W) +YWn>8amqW^:' );
define( 'NONCE_SALT',       '=^5&g|@|nzkdy!-^B1.j:&Bv*{eb$m.JK*m*JhgJA&]{@dVLs3bV4#<wt[xVGb&g' );

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'ko_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define( 'WP_DEBUG', false );

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', dirname( __FILE__ ) . '/' );
}

/** Sets up WordPress vars and included files. */
require_once( ABSPATH . 'wp-settings.php' );
